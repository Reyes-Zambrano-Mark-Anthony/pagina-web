//array de documentos, objetos con id, titulo, fecha de reciente actualizacion, descripcion, y contenido
const docs = [
  {
    id: 1,
    title: "Introducción a la programación",
    date: "2021-07-20",
    description: "Aprende los conceptos básicos de la programación",
    content: "Contenido de la introducción a la programación"
  },
  {
    id: 2,
    title: "Introducción a JavaScript",
    date: "2021-07-21",
    description: "Aprende los conceptos básicos de JavaScript",
    content: "Contenido de la introducción a JavaScript"
  },
  {
    id: 3,
    title: "Introducción a Node.js",
    date: "2021-07-22",
    description: "Aprende los conceptos básicos de Node.js",
    content: "Contenido de la introducción a Node.js"
  },
];

// Path: docs/docs.js

document.getElementById("docs-items").innerHTML = docs.map(
  (doc) => `
<div class="doc-item">
<div class="doc-item__title">
  <h4>Documento ${doc.id}</h4>
  <p>${doc.title} - ${doc.date}</p>
</div>
<div class="doc-item__actions">
  <button class="btn" onclick="viewDoc()" id="view">Ver</button>
  <button class="btn" onclick="downloadDoc()" id="download">Descargar</button>
  <button class="btn" onclick="deleteDoc()" id="delete">Eliminar</button>
</div>
</div>`
).join('');

function viewDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Ver documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });
}

function downloadDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Descargar documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });
}

function deleteDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Eliminar documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });

}

/* <div class="doc-item">
<div class="doc-item__title">
  <h4>Documento 1</h4>
  <p>Nombre documento - Fecha recibido</p>
</div>
<div class="doc-item__actions">
  <button class="btn" id="view">Ver</button>
  <button class="btn" id="download">Descargar</button>
  <button class="btn" id="delete">Eliminar</button>
</div>
</div> */
