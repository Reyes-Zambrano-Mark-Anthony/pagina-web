document.querySelector('form').addEventListener('submit', (e) => {
  e.preventDefault();
  if (document.getElementById("username").value == "admin" && document.getElementById("password").value == "admin") {
    window.location.href = "./dashboard/dashboard.html";
  } else {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Contraseña o usuario incorrecto!',
    });
  }
});