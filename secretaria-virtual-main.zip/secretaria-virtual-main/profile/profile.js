document.getElementById("change-pic").addEventListener("click", function() {
    Swal.fire({
        title: 'Funcion no disponible',
        text: 'Cambiar foto de perfil',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});

document.getElementById("save-changes").addEventListener("click", function() {
    Swal.fire({
        title: 'Cambios realizados',
        text: 'Guardar cambios',
        icon: 'success',
        confirmButtonText: 'Aceptar'
    });
});

document.getElementById("cancel-changes").addEventListener("click", function() {
  window.location.href = "/dashboard/dashboard.html";
});