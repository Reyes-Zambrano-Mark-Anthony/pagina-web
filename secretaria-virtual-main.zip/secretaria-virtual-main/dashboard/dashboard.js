document.getElementById("check-task").addEventListener("click", function() {
  Swal.fire({
    title: "Task Checked",
    text: "Task has been checked successfully",
    icon: "success",
    confirmButtonText: "OK",
  });
});

document.querySelector(".li-calendar").addEventListener("click", function() {
  Swal.fire({
    title: "Calendario",
    text: "No hay eventos en este dia",
    icon: "info",
    confirmButtonText: "OK",
  });
});

document.getElementById("notification").addEventListener("click", function() {
  Swal.fire({
    title: "Notificaciones",
    text: "No hay notificaciones",
    icon: "info",
    confirmButtonText: "OK",
  });
});