document.getElementById("finish-task").addEventListener("click", function() {
  Swal.fire({
    title: "Task Finished",
    text: "Task has been finished successfully",
    icon: "success",
    confirmButtonText: "OK",
  });
});