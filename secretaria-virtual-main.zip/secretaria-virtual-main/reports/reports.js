//array con datos de informes, id, titulo, fecha de creacion, descripcion, emisor y asuton
const reports = [
  {
    id: 1,
    title: "Informe de ventas",
    date: "2021-07-20",
    description: "Informe de ventas del mes",
    sender: "Juan Perez",
    subject: "Informe de ventas"
  },
  {
    id: 2,
    title: "Informe de gastos",
    date: "2021-07-21",
    description: "Informe de gastos del mes",
    sender: "Juan Perez",
    subject: "Informe de gastos"
  },
  {
    id: 3,
    title: "Informe de inventario",
    date: "2021-07-22",
    description: "Informe de inventario del mes",
    sender: "Juan Perez",
    subject: "Informe de inventario"
  },
];

document.getElementById("report-items").innerHTML = reports.map((report) => `
<div class="doc-item">
<div class="doc-item__title">
  <h4>Informe ${report.id}</h4>
  <p>${report.title} - ${report.date}</p>
  <p>${report.sender} - ${report.subject}</p>
</div>
<div class="doc-item__actions">
  <button class="btn" onclick="viewDoc()" id="view">Ver</button>
  <button class="btn" onclick="downloadDoc()" id="download">Descargar</button>
  <button class="btn" onclick="deleteDoc()" id="delete">Eliminar</button>
</div>
</div>`).join('');


function viewDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Ver documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });
}

function downloadDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Descargar documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });
}

function deleteDoc() {
  Swal.fire({
    title: "Funcion no disponible",
    text: "Eliminar documento",
    icon: "info",
    confirmButtonText: "Aceptar",
  });

}
