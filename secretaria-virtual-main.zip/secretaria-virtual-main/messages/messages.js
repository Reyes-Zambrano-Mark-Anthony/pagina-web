document.getElementById("enviar-btn").addEventListener("click", function() {
    var mensaje = document.getElementById("texting-box").value;
    Swal.fire({
        title: 'Funcion no disponible',
        text: mensaje,
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});